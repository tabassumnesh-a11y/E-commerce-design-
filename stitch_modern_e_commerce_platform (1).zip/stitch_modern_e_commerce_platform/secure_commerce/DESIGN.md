---
name: Secure Commerce
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#43474e'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#74777f'
  outline-variant: '#c4c6cf'
  surface-tint: '#455f88'
  primary: '#002045'
  on-primary: '#ffffff'
  primary-container: '#1a365d'
  on-primary-container: '#86a0cd'
  inverse-primary: '#adc7f7'
  secondary: '#595f66'
  on-secondary: '#ffffff'
  secondary-container: '#dde3eb'
  on-secondary-container: '#5f656c'
  tertiary: '#321b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#4f2e00'
  on-tertiary-container: '#c6955e'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3ff'
  primary-fixed-dim: '#adc7f7'
  on-primary-fixed: '#001b3c'
  on-primary-fixed-variant: '#2d476f'
  secondary-fixed: '#dde3eb'
  secondary-fixed-dim: '#c1c7cf'
  on-secondary-fixed: '#161c22'
  on-secondary-fixed-variant: '#41474e'
  tertiary-fixed: '#ffddba'
  tertiary-fixed-dim: '#f2bc82'
  on-tertiary-fixed: '#2b1700'
  on-tertiary-fixed-variant: '#633f0f'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Manrope
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 24px
  container-max: 1280px
---

## Brand & Style

This design system is anchored in **Minimalism** with a **Corporate Modern** execution. The goal is to establish immediate trust and perceived security for a high-end e-commerce environment. By leveraging heavy whitespace and a restricted, purposeful color palette, the interface directs focus toward products while maintaining a professional distance that feels high-quality and reliable.

The aesthetic avoids unnecessary ornamentation, relying instead on precise alignment, generous breathing room, and subtle depth to guide the user journey. The emotional response is one of calm confidence—reassuring the customer that their data and their purchase are in capable hands.

## Colors

The palette is dominated by the primary Navy Blue to evoke stability and institutional strength. The soft Slate Blue serves as a sophisticated alternative to pure white for section backgrounds, adding depth without visual noise.

- **Primary (#1A365D):** Used for headers, primary navigation, and bold type.
- **Secondary (#E2E8F0):** Applied to background fills, borders, and subtle dividers.
- **Accent (#2F855A):** Reserved strictly for primary call-to-action (CTA) buttons, success indicators, and "In Stock" badges to ensure high conversion and positive feedback.
- **Neutrals:** A range of grays derived from the slate family are used for body text (#334155) and labels (#64748B).

## Typography

This design system utilizes a dual-font strategy to balance character with utility. **Manrope** is selected for headlines to provide a modern, refined, and balanced appearance that feels slightly more premium than standard system fonts. **Inter** is used for all body copy, labels, and UI elements to ensure maximum legibility and a systematic, clean feel.

Maintain strict hierarchy by using weight rather than just size. Headlines should favor the Primary Navy Blue, while body text should utilize a deep charcoal for better long-form reading comfort.

## Layout & Spacing

The design system employs a **Fixed Grid** model for large screens, centering the content within a 1280px container to maintain control over line lengths and visual density. The spacing rhythm is based on an 8px baseline grid.

- **Grid:** 12-column layout with 24px gutters.
- **Vertical Spacing:** Use 'XL' (80px) spacing between major sections to emphasize the minimalist aesthetic.
- **Margins:** Page-level horizontal margins should be a minimum of 24px on mobile and scale to fill the viewport until the container max-width is reached.

## Elevation & Depth

Visual hierarchy is established through **Ambient Shadows** and **Tonal Layers**. Shadows should be extremely soft, using the Primary Navy Blue or Slate Blue as a tint rather than pure black to keep the look "airy."

- **Level 1 (Default):** Flat surfaces with subtle 1px borders (#E2E8F0).
- **Level 2 (Cards/Menus):** A soft shadow with 15px blur, 0px offset, and 5% opacity.
- **Level 3 (Modals/Overlays):** A more defined shadow with 30px blur, 10px Y-offset, and 8% opacity.

Avoid heavy gradients. Use background color shifts (White to Slate Blue) to define distinct content zones.

## Shapes

The shape language is defined by a consistent **8px (0.5rem)** corner radius. This "Rounded" setting strikes the perfect balance between the rigidity of sharp corners (which can feel too aggressive) and the playfulness of pill shapes (which can feel too casual). 

- **Small Components:** Checkboxes and small tags use 4px for a sharper look.
- **Standard Components:** Buttons, Input fields, and Product Cards use the 8px standard.
- **Large Components:** Hero images and prominent promotional banners may use 16px (1rem) to soften the layout.

## Components

### Buttons
- **Primary:** Emerald Green fill with White text. No border. High contrast for CTAs.
- **Secondary:** White fill with 1px Navy Blue border and Navy Blue text.
- **Ghost:** Transparent fill with Navy Blue text; used for secondary actions like "Cancel" or "Learn More."

### Input Fields
- White background with a 1px Slate Blue border.
- On focus, the border transitions to Navy Blue with a subtle 2px outer glow in the Primary color at 10% opacity.
- Labels are always positioned above the field in `label-md` weight.

### Product Cards
- White background with a Level 2 shadow on hover.
- High-quality product images should have a slight 50ms transition zoom on hover.
- Price is displayed in Navy Blue bold; "Add to Cart" appears as a full-width Emerald Green button or a prominent icon.

### Chips & Badges
- Used for categories or status.
- "New" or "In Stock" uses Emerald Green with low-opacity green background.
- Filter chips use Slate Blue backgrounds with Navy Blue text.

### Feedback States
- **Success:** Emerald Green (#2F855A).
- **Warning:** Muted Amber (use sparingly).
- **Error:** Soft Crimson (for form validation).